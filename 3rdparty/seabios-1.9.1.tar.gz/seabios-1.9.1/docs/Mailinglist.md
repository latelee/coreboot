For questions and general information about SeaBIOS, please subscribe
to the [SeaBIOS mailing
list](http://www.seabios.org/mailman/listinfo/seabios). If you're not
subscribed, your post will be held temporarily for moderator approval
(to combat spam).

A mailing list archive is available at
<http://www.seabios.org/pipermail/seabios/>
