// Place build generated version into a C variable
#include "autovgaversion.h"
#include "types.h"

char VERSION[] VAR16 = BUILD_VERSION;
char BUILDINFO[] VAR16 = BUILD_TOOLS;
